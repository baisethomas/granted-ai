
# Equity & Accessibility

- Target high‑need neighborhoods with low broadband adoption.
- Bilingual Spanish/English services; other languages by request.
- ADA‑compliant spaces; large‑print materials; captioned video.
- Community advisory input; inclusive materials and facilitation.
- Transportation vouchers, childcare, loaner devices, flexible schedules.
