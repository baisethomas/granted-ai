
# Budget Narrative (Synthetic)

- **Personnel:** Market‑rate compensation for instructors, digital navigators, and coaching staff.
- **Non‑Personnel:** Equipment, software, Tech Bus costs, event supplies, participant stipends.
- **Administration:** Under 10% to meet common funder expectations while maintaining compliance.
- **Match/In‑Kind:** Partner‑provided space, volunteer hours, donated devices/services.
- **Revenue Mix (FY25):** 60% grants, 15% individuals, 15% corporate sponsors, 5% fee‑for‑service, 5% in‑kind.
