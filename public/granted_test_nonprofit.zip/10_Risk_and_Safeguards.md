
# Risk Management & Safeguards

- **Youth Safety:** Background checks; two‑adult rule; mandated reporting.
- **Data Privacy:** Role‑based access; encryption; PII minimization; audits.
- **Continuity:** Backup instructors; remote delivery playbooks; equipment redundancy.
- **Facilities:** Safety checks for the Tech Bus; emergency kits; weather contingencies.
